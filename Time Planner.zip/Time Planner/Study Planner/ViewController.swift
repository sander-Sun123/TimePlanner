//
//  ViewController.swift
//  Study Planner
//
//  Created by Thaw Zin on 17/5/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

