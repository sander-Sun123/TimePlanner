//
//  gameViewController.swift
//  PaoPao
//
//  Created by Sander SUN on 2021/4/22.

import UIKit

class GameViewController: UIViewController
{
 
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var no1Lable: UILabel!
    
    var second = 0
    var Num = 0
    var count = 0
    var score = 0
    var tempBuble = 0.0
    var top1Score = UserDefaults.standard.value(forKey: "top1Score")
    var top2Score = UserDefaults.standard.value(forKey: "top2Score")
    var top3Score = UserDefaults.standard.value(forKey: "top3Score")
    var name = ""
    var bub = [Bubble]()
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        second = UserDefaults.standard.value(forKey: "time") as! Int
        Num = UserDefaults.standard.value(forKey: "Number") as! Int
        no1Lable.text = String(top1Score as! Int)
        

        Timer.scheduledTimer(withTimeInterval: 1, repeats: true){
            [self](timer) in
            
            if  self.second == 0{
                
                name = UserDefaults.standard.string(forKey: "name")!
                print("your name is", self.name)
                timer.invalidate()
                self.scoreSaving()
                performSegue(withIdentifier:"gameFinishSegue", sender:nil)
                
            }
        
            
            else{
                self.second = self.second - 1
                self.timerLabel.text = String(self.second)
                if(count < Num && count >= 0){
                self.bubble()
                    
                   }
                }
            
        }
        
    }
    

 
    func bubble(){
        var bubble = Bubble(frame: view.frame)
        while (marry(new: bubble)){
            bubble = Bubble(frame: view.frame)
        }
        bub.append(bubble)
        
        while (count != bub.count){
            view.addSubview(bub[count])
            count = count + 1
        }
        
        print("count", count)
        delBubble(sender: bubble)
        bubble.addTarget(self, action: #selector(gone), for: .touchUpInside)
 
    }
    

    //let bubble dont stay together
    func marry(new: Bubble) -> Bool{
        let newCgr = new.frame
        for pre in bub {
            if (newCgr.intersects(pre.frame)){
                return true
            }
        }
        return false
    }
    
    
 
    //Let first bubble disapper frome the count number of bubble (bub) in the current time in the screen
    func delBubble (sender: Bubble){
        var timeToRemove = 3
        Timer.scheduledTimer(withTimeInterval: 1,repeats: true){
            (timer) in
            if (timeToRemove == 0){
                sender.removeFromSuperview()
                self.bub.removeFirst()
                self.count = self.bub.count
                timer.invalidate()
                
            }else{
                timeToRemove = timeToRemove - 1
            }
        }
    }
    


    //bubbleanimation
    @objc func gone(sender: Bubble){
        let animation = CABasicAnimation(keyPath: "transform.scale")
        animation.duration = 0.3
        animation.fromValue = 0.5
        animation.toValue = 0
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        sender.layer.add(animation, forKey: nil)
        sender.isEnabled = false
        for i in bub{
            if i.isEqual(sender){
                print("del bub", sender)
                
            }
        }
        
        
        let left = Num - count
        let valiLeft = 3
        if (left > valiLeft){
            let randomCount = Int.random(in: 0...valiLeft)
            var i = 0
            while (i < randomCount){
                bubble()
                i = i + 1

            }
        }

        
        
        
        //score add together has 1.5 reward
        let tempScore = Double(sender.score)
        
        if (tempScore == tempBuble){
            score = score + Int(round(tempScore * 1.5))
        }
       
        else{
            tempBuble = tempScore
            score = score + Int(tempScore)
            
        }
        scoreLabel.text = String(Int(score))
        
        }
    
    
    
    //Score Location and more
    func scoreSaving(){
        if (score > top1Score as! Int){
            print("top1score is ",score, "and top1name is", name )
            let t1s = UserDefaults.standard.value(forKey: "top1Score")
            let t1n = UserDefaults.standard.value(forKey: "top1Name")
            let t2s = UserDefaults.standard.value(forKey: "top2Score")
            let t2n = UserDefaults.standard.value(forKey: "top2Name")
            
            
            UserDefaults.standard.setValue(score, forKey: "top1Score")
            UserDefaults.standard.setValue(name, forKey: "top1Name")
            
            UserDefaults.standard.setValue(t1s, forKey: "top2Score")
            UserDefaults.standard.setValue(t1n, forKey: "top2Name")
            
            UserDefaults.standard.setValue(t2s, forKey: "top3Score")
            UserDefaults.standard.setValue(t2n, forKey: "top3Name")
            
        }
        else if (score > top2Score as! Int){
            print("top2score is ",score, "and top2name is", name )
            
            let t2s = UserDefaults.standard.value(forKey: "top2Score")
            let t2n = UserDefaults.standard.value(forKey: "top2Name")
            
            UserDefaults.standard.setValue(score, forKey: "top2Score")
            UserDefaults.standard.setValue(name, forKey: "top2Name")
            
            UserDefaults.standard.setValue(t2s, forKey: "top3Score")
            UserDefaults.standard.setValue(t2n, forKey: "top3Name")
            
        }
        else  if (score > top3Score as! Int){
            print("top3score is ",score, "and top3name is", name )
            UserDefaults.standard.setValue(score, forKey: "top3Score")
            UserDefaults.standard.setValue(name, forKey: "top3Name")
        }
    }
}
