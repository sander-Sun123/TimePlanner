//
//  bubble.swift
//  PaoPao
//
//  Created by Sander SUN on 2021/4/23.
//

import UIKit

class Bubble: UIButton

{
    var score = 0
    var bub = [CGRect]()
    
    override init(frame:CGRect){
        super.init(frame: frame)
         colorScore()
        
        
        //let Button do not going out
        let x = CGFloat.random(in: 0...frame.width - 40)
        let y = CGFloat.random(in: 200...frame.height - 40)
   
        // RectButton tobe circle
        self.frame = CGRect(x: x, y: y, width: 40, height: 40)
        self.layer.cornerRadius = 20
        

    }
    
    
    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
   
    }
    


    
    //different bubble different color
    func colorScore(){
        let num = Int.random(in: 0...100)
        switch num{
        
        case 0...40:
        self.backgroundColor = #colorLiteral(red: 0.9614012837, green: 0, blue: 0, alpha: 1)
        score = 1
                
        case 41...70:
        self.backgroundColor = #colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1)
        score = 2
            
        case 71...85:
        self.backgroundColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
        score = 5
            
        case 86...95:
        self.backgroundColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        score = 8
            
            
        default:
        self.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        score = 10
        }
    }
  

}
