//
//  HistoryViewController.swift
//  PaoPao
//
//  Created by Sander SUN on 2021/4/22.
//

import UIKit

class HistoryViewController: UIViewController {


    @IBOutlet weak var Top1Name: UILabel!
    @IBOutlet weak var Top1Score: UILabel!
    var top1Name = UserDefaults.standard.value(forKey: "top1Name") as! String
    var top1Score = UserDefaults.standard.value(forKey: "top1Score") as! Int
    
    @IBOutlet weak var Top2Name: UILabel!
    @IBOutlet weak var Top2Score: UILabel!
    var top2Name = UserDefaults.standard.value(forKey: "top2Name") as! String
    var top2Score = UserDefaults.standard.value(forKey: "top2Score") as! Int
    
    @IBOutlet weak var Top3Name: UILabel!  
    @IBOutlet weak var Top3Score: UILabel!
    var top3Name = UserDefaults.standard.value(forKey: "top3Name") as! String
    var top3Score = UserDefaults.standard.value(forKey: "top3Score") as! Int
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        Top1Name.text = top1Name
        Top1Score.text = String(top1Score)

        Top2Name.text = top2Name
        Top2Score.text = String(top2Score)
        
        Top3Name.text = top3Name
        Top3Score.text = String(top3Score)


    }
}

