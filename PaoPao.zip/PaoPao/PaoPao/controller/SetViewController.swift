//
//  SetViewController.swift
//  PaoPao
//
//  Created by Sander SUN on 2021/4/22.
//

import UIKit

class SetViewController: UIViewController {

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var timeslider: UISlider!
    
    @IBOutlet weak var NumLabel: UILabel!
    @IBOutlet weak var Numslider: UISlider!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    @IBAction func timeChange(_ sender: Any) {
        timeLabel.text = String(Int(timeslider.value))
    }
    @IBAction func NumChange(_ sender: Any) {
        NumLabel.text = String(Int(Numslider.value))
    }

    @IBAction func done(_ sender: Any) {
        let userDefault = UserDefaults.standard
        
        userDefault.setValue(Int(timeslider.value), forKey: "time")
        
        userDefault.setValue(Int(Numslider.value), forKey: "Number")

        
    }
    
    
}
