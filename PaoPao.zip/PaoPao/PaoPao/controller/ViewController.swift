//
//  ViewController.swift
//  PaoPao
//
//  Created by Sander SUN on 2021/4/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var NameTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
 
        //check top1Score, top2Score, top3Score ，and to equal nil
        let top1Score = UserDefaults.standard.value(forKey: "top1Score")
        let top2Score = UserDefaults.standard.value(forKey: "top2Score")
        let top3Score = UserDefaults.standard.value(forKey: "top3Score")
        let second = UserDefaults.standard.value(forKey: "time")
        let Num = UserDefaults.standard.value(forKey: "Number")
        
        if (second == nil){
            UserDefaults.standard.setValue(60, forKey: "time")
        }
        
        if (Num == nil) {
            UserDefaults.standard.setValue(15, forKey: "Number")
        }
        
        if (top1Score == nil){
            UserDefaults.standard.setValue(0, forKey: "top1Score")
            UserDefaults.standard.setValue("NONE", forKey: "top1Name")
            print("lalala")
        }
        
        if (top2Score == nil){
            UserDefaults.standard.setValue(0, forKey: "top2Score")
            UserDefaults.standard.setValue("NONE", forKey: "top2Name")
            print("set 0 to top2Score")
            
        }

        if (top3Score == nil){
            UserDefaults.standard.setValue(0, forKey: "top3Score")
            UserDefaults.standard.setValue("NONE", forKey: "top3Name")
            print("set 0 to top3Score")
            
        }
    }
    
    

    @IBAction func goButton(sender: Any) {
        if NameTextField.text!.count > 0{
            //turn to next page
            performSegue(withIdentifier:"gameSegue", sender:nil)
            let name = String(NameTextField.text!)
            print("current name is ",name)
            UserDefaults.standard.set(name, forKey: "name")
        }    }
    
}
